package ru.moi.ai

/**
 * Точка интеграции локального inference.
 *
 * Следующий шаг: подключить совместимую версию LiteRT-LM,
 * загрузку модели из локального хранилища и потоковую генерацию.
 *
 * Не добавляйте сюда ключи платных API: цель проекта — полностью
 * локальная работа без подписки и обязательного интернета.
 */
interface LocalModel {
    suspend fun load(modelPath: String)
    suspend fun generate(prompt: String, onToken: (String) -> Unit)
    fun close()
}

package ru.moi.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF212121)
private val Panel = Color(0xFF2F2F2F)
private val TextMain = Color(0xFFECECEC)
private val Muted = Color(0xFFAAAAAA)
private val Accent = Color(0xFF19C37D)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MoiAiApp() }
    }
}

@Composable
fun MoiAiApp() {
    var input by remember { mutableStateOf("") }
    var drawer by remember { mutableStateOf(false) }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var status by remember { mutableStateOf("Локальная модель не подключена") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Bg, onBackground = TextMain,
        onSurface = TextMain, primary = Accent
    )) {
        Row(Modifier.fillMaxSize().background(Bg)) {
            if (drawer) {
                Column(
                    Modifier.width(280.dp).fillMaxHeight().background(Color(0xFF171717)).padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Мой AI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextMain)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { drawer = false }) { Icon(Icons.Default.Close, null, tint = TextMain) }
                    }
                    Spacer(Modifier.height(20.dp))
                    DrawerItem("＋  Новый чат") { messages = emptyList(); drawer = false }
                    DrawerItem("⌕  Поиск") { drawer = false }
                    Spacer(Modifier.weight(1f))
                    Text(status, color = Muted, fontSize = 12.sp)
                    DrawerItem("⚙  Настройки") { drawer = false }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(
                    Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { drawer = !drawer }) {
                        Icon(Icons.Default.Menu, "Меню", tint = TextMain)
                    }
                    Text("Мой AI", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextMain)
                    Spacer(Modifier.width(8.dp))
                    Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
                        Text("Локальный режим", color = Muted, fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { messages = emptyList() }) {
                        Icon(Icons.Default.Edit, "Новый чат", tint = TextMain)
                    }
                }

                if (messages.isEmpty()) {
                    Column(
                        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(54.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
                            Text("✳", color = Accent, fontSize = 30.sp)
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("Чем могу помочь?", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text("Ваш личный ИИ-помощник на устройстве", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(28.dp))
                        Suggestion("Объясни сложную тему простыми словами") { input = "Объясни сложную тему простыми словами" }
                        Suggestion("Помоги написать текст") { input = "Помоги написать текст" }
                        Suggestion("Придумай идею для проекта") { input = "Придумай идею для проекта" }
                    }
                } else {
                    LazyColumn(
                        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                        contentPadding = PaddingValues(vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        items(messages) { msg ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement =
                                if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                                Surface(
                                    color = if (msg.fromUser) Panel else Bg,
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.widthIn(max = 310.dp)
                                ) {
                                    Text(msg.text, color = TextMain, modifier = Modifier.padding(14.dp), fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }

                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Surface(color = Panel, shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { /* attachment entry point */ }) {
                                Icon(Icons.Default.Add, "Добавить", tint = Muted)
                            }
                            TextField(
                                value = input, onValueChange = { input = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("Спросите что угодно", color = Muted) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedTextColor = TextMain, unfocusedTextColor = TextMain,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                maxLines = 5
                            )
                            IconButton(onClick = {
                                val prompt = input.trim()
                                if (prompt.isNotEmpty()) {
                                    messages = messages + ChatMessage(prompt, true)
                                    // TODO: Send prompt to the on-device LiteRT-LM model.
                                    messages = messages + ChatMessage(
                                        "Интерфейс готов. Для генерации ответов подключите локальную языковую модель в LocalModel.kt.",
                                        false
                                    )
                                    input = ""
                                }
                            }, enabled = input.isNotBlank()) {
                                Icon(Icons.Default.ArrowUpward, "Отправить",
                                    tint = if (input.isNotBlank()) Color.Black else Muted,
                                    modifier = Modifier.background(
                                        if (input.isNotBlank()) Accent else Color(0xFF555555), CircleShape
                                    ).padding(8.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(7.dp))
                    Text("Ответы создаются локальной моделью после её подключения.", color = Muted,
                        fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        }
    }
}

@Composable
private fun DrawerItem(label: String, onClick: () -> Unit) {
    Text(label, color = TextMain, fontSize = 15.sp,
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 14.dp))
}

@Composable
private fun Suggestion(label: String, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onClick() }) {
        Text(label, color = TextMain, fontSize = 14.sp, modifier = Modifier.padding(14.dp))
    }
}
